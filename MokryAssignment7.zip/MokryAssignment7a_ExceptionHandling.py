#-------------------------------------------------#
# Title: Exception Handling
# Dev:   Nathanael Mokry
# Date:  August 26, 2018
# ChangeLog: (Who, When, What)
#-------------------------------------------------#

# This program creates a simple example of how you would
# use Python Exception/Error Handling.

#-- Data --#
# declare variables and constants
# userInput = user enter value, that 10 will be divided by

#-- Input/Output --#
# User is prompted to enter a value
# user can see 1 of 2 error messages if they enter wrong value
# user will be displayed value divided by 10

# -- Processing --#
try:
    # When the program starts, it asks the user to enter a value
    # that user is converted to an integer, and then the number 10 is divided by that number
    userInput = int(input("The number 10 will be divided by the value you enter 10: "))
    print("10 divided by ",str(userInput)+" is: ", 10/userInput)
# if a value error occurs, the user is shown a ValueError message
except ValueError as e:
    print("There was an error with your entry.")
    print("It looks like you entered something that could not be converted to an integer.")
    print("Python's error description: ", e)
# if a ZeroDivisionError occurs, the user is shown a ZeroDivisionError message
except ZeroDivisionError as e:
    print("There was an error with your entry.")
    print("It looks like you tried to divide a number by 0.")
    print("Python's error description: ", e)