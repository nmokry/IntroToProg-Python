#-------------------------------------------------#
# Title: Pickle Data
# Dev:   Nathanael Mokry
# Date:  August 28, 2018
# ChangeLog: (Who, When, What)
#-------------------------------------------------#

# This program creates a simple example of how you would Pickle Data
# It will display how to save data to a binary file, and read that data
# back, or Pickling/Unpickling

#-- Data --#
# declare variables and constants
# objFile = variable with file directory stored
dicData = {"Fruit":"Apple","Vegetable":"Celery","Meat":"Chicken"} # Data stored in a dictionary
unPickledDicData = {} # a variable storing the data that is read/unpickled from the .dat file
objFileName = "PickleData.dat" # the name of the file where data will be stored to

#-- Input/Output --#
# User is shown the dictionary that is going to be pickled
# User is notified that the pickling has taken place
# user user is shown the data that has been un-pickled from the file

# -- Processing --#

# open the pickle Module so that we can use this functionality
import pickle
# Explain to the user what is going to happen
print("This Progarm Pickles and Unpickles the following dictionary of data")
print('{"Fruit":"Apple","Vegetable":"Celery","Meat":"Chicken"}'+"\n")
input("Press enter to pickle this data. ")

# Open the file, and create it, if it doesn't already exist
objFile = open(objFileName, "wb+")
# Pickle data here
pickle.dump(dicData,objFile)
# close the file, ensuring that the data is saved to the file
objFile.close()

# Explain to the user what is happening
input("Your Data has been pickled to PickleData.dat! Press enter to continue.")
input("Now we will unpickle this data. Press Enter to continue. ")

# re-open the file, but in read mode
objFile = open(objFileName, "rb")
# Unpickle data here & store the data in a variable
unPickledDicData = pickle.load(objFile)

#Show the user what was in the file. It should be a dictionary
print("here is the un-pickled dictionary data from the .dat file \n")
print(unPickledDicData,"\n")
objFile.close()
input("Exciting, right?! Press any key to exit. ")
