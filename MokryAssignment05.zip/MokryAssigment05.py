#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Nathanael Mokry, 08/13/2018, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# row = A row of text data from the file
# strTask = Task parsed from the string data
# strPriority = Priority parsed from the string data
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection
# newStrTask = Name of new task to be added to task list
# newStrPriority = Mame of new priority to be added to task list
# strRemoveItem = name of task to be deleted from task list
# strResult = resulting text to be displayed if item to be removed is or is not found in task list
# intIndex = indext of list table item to be be removed from last



#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

objFile = "C:\\Users\\nmokry\\Desktop\\Python_Class\\Class_Docs\\Module05\\ToDo.txt"
dicRow = {}
lstTable = []

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
objFile = open(objFile,"r")
# start looping through the text file, row by row
for row in objFile:
    # parse the task data & save its pieces to string variables
    # first clean up the text row by replacing uncessary characters
    row=row.replace("\n", "")
    # then, split the text row coming from the text file by the comma
    listRow=row.split(",")
    # then parse the resulting list,saving the individual elements to string variables
    strTask = listRow[0].title()
    strPriority = listRow[1].title()
    # Then create your dictionary
    dicRow={"Task":strTask,"Priority":strPriority}
    # then append this data to the string that you will use later
    lstTable.append(dicRow)
# Display the contents of the list to the user
print("Here are the your tasks and priorities: \n")
# loop through each dictionary row in the list table
for dicRow in lstTable:
    # show the values for each of the dictionary keys requested below
    print(dicRow["Task"]+": "+dicRow["Priority"])
# close the file
objFile.close()

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        # loop through each dictionary row in the list table
        for dicRow in lstTable:
            # loop through each dictionary row in the list table
            print(dicRow["Task"] + ": " + dicRow["Priority"])
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        # ask the user what task they want to add. store it in a variable
        newStrTask=input("What is the new task you want to add? ").title()
        # ask the user what the priority for that new task is. Store it in a variable
        newStrPriority = input("What is the priority of this new task? ").title()
        #take the two variables and enter them into a new dictionary row
        newDicRow = {"Task":newStrTask,"Priority":newStrPriority}
        # add that dictionary row to your list table
        lstTable.append(newDicRow)
        print("You have successfully added a task and associated priority to your task list")
        continue
    # Step 5 - Remove an item from the list/Table
    elif(strChoice.strip() == '3'):
        #ask the user for the item they want to delete. store it in a variable
        strRemoveItem = input("Enter the text of the task you want to remove: ").title()
        # store a default string to be displayed later at the end of the loop for this delete step
        strResult = "\nThis item was not found in the list. Please check your spelling and try again."
        # store an empty default index for the listTable. Only populate it with an index if the requested item
        # is found in the list table
        intIndex = ''
        # loop through the list table
        for dicRow in lstTable:
            # search through each dictionary, and if task is found, return the index of the list element
            if strRemoveItem.title() in dicRow.values():
                # if item is found, change the default string that will be displayed later
                strResult = "\nThe following task has been deleted: "+strRemoveItem.title()+".\nMake sure to save the data to file before exiting the program."
                # find index of list table element that has the item
                intIndex = lstTable.index(dicRow)
                # delete that item from the list
                lstTable.pop(intIndex)
            else: ""
        # show the result. It will show the default if the requested task is not found in the list, or it will show
        # the updated result if the item is found
        print(strResult)
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        # open the .txt file
        objFile = "C:\\Users\\nmokry\\Desktop\\Python_Class\\Class_Docs\\Module05\\ToDo.txt"
        # however, this time we open it in write mode. This deletes anything that was previously in the list
        objFile = open(objFile, "w")
        # loop through the list table
        for dicRow in lstTable:
            # save the items in the list to the file
            objFile.write(dicRow["Task"]+","+dicRow["Priority"]+"\n")
        # close the file
        objFile.close()
        print("You have successfully saved your task list")
        continue
    elif (strChoice == '5'):
        print("Goodbye!")
        break #and Exit the program
    # close the file

