#-------------------------------------------------#
# Title: Using Classes
# Dev:   Rroot
# Date:  August 26, 2018
# ChangeLog: (Who, When, What)
# Nathanael Mokry, 09/04/18, Re-organized Rroots code by using a class for the product data and methods below
#-------------------------------------------------#

# --- Make the class ---
class ProductProcessor(object):
    """ Base Class for Personal data """
    # -------------------------------------#
    # Desc:  Holds Data used for storing product Dat in a file
    # Dev:   Nathanael Mokry
    # Date:  09/05/2018
    # -------------------------------------#

    # --Fields--
    ID=0 # product ID
    Product="" # product description
    Price=0.0 # Holds the price for the item
    UserInput = ""  # A string which holds user input
    File = None # this holds the file object used within this class

    # --Constructor--
    # Attributes
    def __init__(self, Id="", Product="", Price=""):
        # Attributes
        self.Id = Id
        self.Product = Product
        self.Price = Price

    # --Methods--
    # This method returns a combined string of the 3 attributes of a product
    # we needs these returned as as string to write to a text file
    def toString(self):
        return self.Id + ", " + self.Product + ", "+self.Price

    # this function both asks the user for the item they want to add, and writes it to file
    def ObtainAndWrite(File):
        try:
            print("Type in a Product Id, Name, and Price you want to add to the file")
            print("(Enter 'Exit' to quit!)")
            while (True):
                strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
                # Parse the user input into seperate variables
                listUserInput = strUserInput.split(",")
                # Create an object from the parsed data
                objProduct = ProductProcessor(listUserInput[0], listUserInput[1], listUserInput[2])
                if (strUserInput.lower() == "exit"):
                    break
                else:
                    # write the product Object to file using the toString method outlined above
                    File.write(objProduct.toString() + "\n")
        except Exception as e:
            print("Error: " + str(e))

    #This method reads the data that was saved to a text file
    def Read(File, Message=""):
        try:
            print(Message)
            File.seek(0)
            print(File.read())
        except Exception as e:
            print("Error: " + str(e))

# --End of class--

#Data
objFile = None  # File Handle

#I/O
try:
  objFile = open("Products.txt", "r+")
  ProductProcessor.Read(objFile, "Here is the current data:") #Call the read method in the Product Proccessor class
  ProductProcessor.ObtainAndWrite(objFile) # call the ObtainAndWrite method in the Product Processor class
  ProductProcessor.Read(objFile, "Here is this data that was saved:") #Call the read method in the Product Proccessor class
except FileNotFoundError as e:
     print("Error: " + str(e) + "\n Please check the file name")
except Exception as e:
    print("Error: " + str(e))
finally:
  if(objFile != None):objFile.close()
