import DataProcessor, Persons, Customers

print("Test the DataProcessor.File class")
objDP = DataProcessor.File()
objDP.FileName = "Test.txt"
objDP.TextData = "This is a test"
strMessage = objDP.SaveData()
print(strMessage)

print("\n Test the DataProcessor.Database class")
try:
    print("Trying to create an object, but the class is not ready")
    objDP = DataProcessor.Database()
except:
    print("This should fail")

print("\n Test the Persons.Person class")
objP = Persons.Person()
objP.FirstName = "Bob"
objP.LastName = "Smith"
print(objP.ToString())

print("\n Test the Employees.Employee class")
objC = Customers.Customer()
objC.Id = 1
objC.FirstName = "Bob"
objC.LastName = "Smith"
print(objC.ToString())

print("\n Test the Employee.EmployeeList class")
objCL = Customers.CustomerList()
try:
    print("Trying the wrong object type")
    objCL.AddCustomer(objP)
except:
    print("This should fail")

try:
    objCL.AddCustomer(objE)
    print("Trying the correct object type")
    print(objCL.ToString())
except:
    print("This should work")


