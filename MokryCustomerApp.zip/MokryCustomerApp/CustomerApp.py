# -------------------------------------------------#
# Title: CustomerApp
# Dev:   RRoot
# Date:  12/12/2020
# Desc: This application manages employee data
# ChangeLog: (Who, When, What)
# Nathanael Mokry, 09/08/2018, Adapted the original Employee App to Become a "CustomerApp"
#
# -------------------------------------------------#

#error handling to ensure that user select the correct main file
if __name__ == "__main__":
    import DataProcessor, Customers
else:
    raise Exception("This file was not created to be imported")

# -- Data --#
# declare variables and constants
objC = None  # an Customer object
intId = 0  # an CustomerId
gIntLastId = 0  # Records the last CustomerId used in the client
strFirstName = ""  # an Customer's first name
strLastName = ""  # an Customer's last name
strInput = ""  # temporary user input


# -- Processing --#
# perform tasks
def ProcessNewCustomerData(Id, FirstName, LastName):
    try:
        # Create Customer object
        objC = Customers.Customer()
        objC.Id = Id
        objC.FirstName = FirstName
        objC.LastName = LastName
        Customers.CustomerList.AddCustomer(objC)
    except Exception as e:
        print(e)


def SaveDataToFile():
    try:
        objF = DataProcessor.File()
        objF.FileName = "CustomerData.txt"
        objF.TextData = Customers.CustomerList.ToString()
        print("Reached here")
        objF.SaveData()
    except Exception as e:
        print(e)

# -- Presentation (I/O) --#
# __main__

# get user input
strUserInput = ""
while (True):
    strUserInput = input("Would you like to add Customer data? (y/n)")
    if (strUserInput.lower() == "y"):
        # Get Customer Id from the User
        intId = int(input("Enter an Customer Id (Last id was " + str(gIntLastId) + "): "))
        gIntLastId = intId
        # Get Customer FirstName from the User
        strFirstName = str(input("Enter an Customer First Name: "))
        # Get Customer LastName from the User
        strLastName = str(input("Enter an Customer Last Name: "))
        # Process input
        ProcessNewCustomerData(intId, strFirstName, strLastName)
    else:
        break

    # send program output
print("The Current Data is: ")
print("------------------------")
print(Customers.CustomerList.ToString())

# get user input
strInput = input("Would you like to save this data to the dat file?(y/n)")
if (strInput == "y"):
    SaveDataToFile()
    # send program output
    print("data saved in file")
else:
    print("data was not saved")

print("This application has ended. Thank you!")
